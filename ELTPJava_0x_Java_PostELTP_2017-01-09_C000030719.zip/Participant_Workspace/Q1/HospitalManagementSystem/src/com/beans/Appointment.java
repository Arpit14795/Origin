package com.beans;

import java.util.Date;
import java.util.List;

public class Appointment {
	 	private int appointmentId;
	 	private int doctorId;
	 	private Date appointmentDate;
	 	private String analysisReport;
	 	private List<Tests> tests;
	 	
	 	public Appointment() {
			// TODO Auto-generated constructor stub
		}
	 	
		public int getAppointmentId() {
			return appointmentId;
		}
		public void setAppointmentId(int appointmentId) {
			this.appointmentId = appointmentId;
		}
		public Date getAppointmentDate() {
			return appointmentDate;
		}
		public void setAppointmentDate(Date appointmentDate) {
			this.appointmentDate = appointmentDate;
		}
		public String getAnalysisReport() {
			return analysisReport;
		}
		public void setAnalysisReport(String analysisReport) {
			this.analysisReport = analysisReport;
		}
		public int getDoctorId() {
			return doctorId;
		}
		public void setDoctorId(int doctorId) {
			this.doctorId = doctorId;
		}
		public List<Tests> getTests() {
			return tests;
		}
		public void setTests(List<Tests> tests) {
			this.tests = tests;
		}
	 	
	 
		
}
