package com.beans;

import java.util.List;

public class Doctor {
	private int doctorId;
	private String doctorName;
	private String specialty;
	private List<String> availability;
	private double consultationCharges;
	
	public Doctor() {
	}

	public int getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public String getSpecialty() {
		return specialty;
	}

	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}

	public List<String> getAvailability() {
		return availability;
	}

	public void setAvailability(List<String> availability) {
		this.availability = availability;
	}

	public double getConsultationCharges() {
		return consultationCharges;
	}

	public void setConsultationCharges(double consultationCharges) {
		this.consultationCharges = consultationCharges;
	}
	
	
	
}
