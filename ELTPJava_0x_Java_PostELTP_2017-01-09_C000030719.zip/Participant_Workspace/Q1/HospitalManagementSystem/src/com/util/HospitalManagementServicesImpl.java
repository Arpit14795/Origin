package com.util;


public class HospitalManagementServicesImpl implements
		HospitalManagementServices {

	

}
