package com.client;


public class Client {
	public static void main(String[] args) {
		// call your implemented methods from here
	}
}
